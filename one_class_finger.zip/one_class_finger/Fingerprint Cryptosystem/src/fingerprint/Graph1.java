/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package fingerprint;
import java.awt.Color;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;

import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;

import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

/**
 *
 * @author admin
 */
public class Graph1 
{
    Details dt=new Details();
    public void display()
    {
        try
        {
            XYSeriesCollection dataset = new XYSeriesCollection();
            XYSeries series1 = new XYSeries("");
            
            for(int i=0;i<dt.vault.size();i++)
            {
                String g1[]=dt.vault.get(i).toString().split("#");
                series1.add(Double.parseDouble(g1[0]),Double.parseDouble(g1[1]));
            }
            
            dataset.addSeries(series1);
            JFreeChart chart = ChartFactory.createXYLineChart(
                "Fuzzy Vault",      
                "x",                      
                "p(x)",                   
                dataset,                  
                PlotOrientation.VERTICAL,
                false,                     
                true,                     
                false                     
            );
             chart.setBackgroundPaint(Color.white);
             final XYPlot plot = chart.getXYPlot();
            plot.setBackgroundPaint(Color.lightGray);
            plot.setDomainGridlinePaint(Color.white);
            plot.setRangeGridlinePaint(Color.white);
        
            final XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
            renderer.setSeriesLinesVisible(0, true);
            final NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
            rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
            rangeAxis.setAutoRangeIncludesZero(true);
            
             ChartFrame frame1=new ChartFrame("Fuzzy Vault",chart);
  
            frame1.setSize(700,500);
  
            frame1.setVisible(true);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}
