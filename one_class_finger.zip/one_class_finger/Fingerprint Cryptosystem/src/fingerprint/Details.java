/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package fingerprint;
import java.util.ArrayList;

/**
 *
 * @author admin
 */
public class Details
{
    static String inPath="";
    static ArrayList features=new ArrayList();
    static ArrayList Qryfeatures=new ArrayList();
    static double we=0.2;
    static ArrayList selFeat=new ArrayList();
    static ArrayList QryselFeat=new ArrayList();
    static ArrayList chaff=new ArrayList();
    static double minDis=180;//9.0;
    static ArrayList distance=new ArrayList();
    static ArrayList Qrydistance=new ArrayList();
    
    static ArrayList Qvk=new ArrayList();
    static ArrayList Tvk=new ArrayList();
    static ArrayList vault=new ArrayList();
    static ArrayList shamir=new ArrayList();
    static double lagx[];
    static double lagy[];
    static double lagx2[];
    
    static String code="";
}
